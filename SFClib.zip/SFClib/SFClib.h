#ifndef SFClib
#define SFClib
#include <Arduino.h>

void SFC_init();
void SFCstart();
void merkerPin(int nmerker, int pinconnection);
void merkerTran(int nmerker1, int transet);
void tranSet(int ntrans, int npin, int valueactivation, int markerset);
#endif