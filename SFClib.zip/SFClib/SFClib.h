#ifndef SFClib
#define SFClib
#include <Arduino.h>
//int timers[30];

void SFC_init();
void SFCstart();
void merkerPin(int nmerker, int pinconnection);
void merkerTran(int nmerker1, int transet);
void tranSet(int ntrans, int npin, int valueactivation, int markerset);
//void timerSet(int nmerker1,int ntrans2, int ntimer, int tempotimer);
#endif