#include <SFClib.h>

uint8_t   tran1[50][2];
int       timer[20];
bool       tran[50][2];
bool    merker1[50][20];
uint8_t merker2[50][5];
uint8_t in, inn, merker=1;
unsigned long T;
void SFC_init(){
  for(in=0;in<=49;in++){
    for(inn=0;inn<=1;inn++){
      tran[inn][in]=0;
      tran1[inn][in]=0;
    }
    for(inn=0;inn<=19;inn++){
      merker1[inn][in]=0;
    }
    for(inn=0;inn<=4;inn++){
      merker2[inn][in]=0;
    }
  }
  for(in=0;in<=19;in++){
    timer[in]=0;
  }
}
void SFCstart(){
  T=millis();
  while(1==1){
    for(in=0;in<=19;in++){
      digitalWrite(in,merker1[merker-1][in]);
    }
    for(in=0;in<=4;in++){
      if(merker2[merker-1][in]>0){
        tran[(merker2[merker-1][in]-1)][0]=1;
      }
    }
    for(in=0;in<=49;in++){
      if(tran[in][0]==1){
        if(tran1[in][0]<=19){
          if(digitalRead(tran1[in][0])==tran[in][1]){
            for(inn=0;inn<=49;inn++){
              tran[inn][0]=0;
            }
            merker=tran1[in][1];
            delay(400);
            T=millis();
          }
        }else if(tran1[in][0]<=39){
          if((millis()-T)>=timer[tran1[in][0]-20]){
            for(inn=0;inn<=49;inn++){
              tran[inn][0]=0;
            }
            merker=tran1[in][1];
            T=millis();
          }
        }
      }
    }
  }
}
void merkerPin(int nmerker, int pinconnection){
  if(pinconnection>19){
    pinconnection=19;
  }
  if(pinconnection<0){
    pinconnection=0;
  }
  if(nmerker>50){
    nmerker=50;
  }
  if(nmerker<1){
    nmerker=1;
  }
  pinMode(pinconnection,OUTPUT);
  merker1[nmerker-1][pinconnection]=1;
}
void merkerTran(int nmerker1, int transet){
  if(transet>50){
    transet=50;
  }
  if(transet<1){
    transet=1;
  }
  if(nmerker1>50){
    nmerker1=50;
  }
  if(nmerker1<1){
    nmerker1=1;
  }
  if(merker2[nmerker1-1][0]==0){
    merker2[nmerker1-1][0]=transet;
  }else if(merker2[nmerker1-1][1]==0){
    merker2[nmerker1-1][1]=transet;
  }else if(merker2[nmerker1-1][2]==0){
    merker2[nmerker1-1][2]=transet;
  }else if(merker2[nmerker1-1][3]==0){
    merker2[nmerker1-1][3]=transet;
  }else if(merker2[nmerker1-1][4]==0){
    merker2[nmerker1-1][4]=transet;
  }
}
void tranSet(int ntrans, int npin, int valueactivation, int markerset){
  if(ntrans>50){
    ntrans=50;
  }
  if(ntrans<1){
    ntrans=1;
  }
  if(npin>39){
    npin=39;
  }
  if(npin<0){
    npin=0;
  }
  if(valueactivation<0){
    valueactivation=0;
  }
  if(markerset>50){
    markerset=50;
  }
  if(markerset<1){
    markerset=1;
  }
  if(npin<=19){
    if(valueactivation>1){
      valueactivation=1;
    }
   pinMode(npin,INPUT);
    tran1[ntrans-1][0]=npin;
    tran1[ntrans-1][1]=markerset;
     tran[ntrans-1][1]=valueactivation;
  }else if(npin<=39){
    tran1[ntrans-1][0]=npin;
    tran1[ntrans-1][1]=markerset;
    timer[npin-20]=valueactivation;
  }
}